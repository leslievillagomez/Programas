<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<footer>
    <div class="footer-content">
    <img src="./recursos/pac.png" alt="logo" class="imagen-derecha">
        <p>Login Web. Todos los derechos reservados.</p>
        <nav>
            <ul>
           <ol> <a>Sobre Nosotros</a></ol>
           <ol><a>Política de Privacidad</a></ol>
           <ol><a>Contacto</a></ol>
           <ol><a>Preguntas Frecuentes</a></ol>
            </ul>
        </nav>
    </div>
    <p>.</p>
    <p>.</p>
    <p>.</p>
</footer>
</body>
</html>